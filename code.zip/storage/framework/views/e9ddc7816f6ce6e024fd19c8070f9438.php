<?php $__env->startSection('title', 'Kelola Pengumuman | DonorDarah'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="h2 fw-bold">Kelola Pengumuman</h1><p class="text-secondary mb-0">Informasi ini akan tampil pada dashboard pendonor.</p></div>
    <a href="<?php echo e(route('admin.announcements.create')); ?>" class="btn btn-danger btn-lg d-inline-flex align-items-center justify-content-center flex-shrink-0 px-4"><span class="me-2" aria-hidden="true">＋</span>Buat Pengumuman</a>
</div>
<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="small text-danger fw-semibold"><?php echo e($announcement->created_at->format('d M Y')); ?></div>
                    <h2 class="h5 fw-bold mt-2"><?php echo e($announcement->title); ?></h2>
                    <p class="text-secondary"><?php echo e($announcement->content); ?></p>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.announcements.edit', $announcement)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                        <form method="POST" action="<?php echo e(route('admin.announcements.destroy', $announcement)); ?>" onsubmit="return confirm('Hapus pengumuman ini?');"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12"><div class="alert alert-info">Belum ada pengumuman. Buat pengumuman pertama.</div></div>
    <?php endif; ?>
</div>
<?php if($announcements->hasPages()): ?><div class="mt-3"><?php echo e($announcements->links()); ?></div><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LSP_Donor_Darah\LSP_Donor_Darah\resources\views/admin/announcements/index.blade.php ENDPATH**/ ?>