<?php $__env->startSection('title', 'Kelola Jadwal | DonorDarah'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
    <div><h1 class="h2 fw-bold">Kelola Jadwal Donor</h1><p class="text-secondary mb-0">Tambah, ubah, tutup, atau hapus jadwal donor.</p></div>
    <a href="<?php echo e(route('admin.schedules.create')); ?>" class="btn btn-danger btn-lg d-inline-flex align-items-center justify-content-center flex-shrink-0 px-4"><span class="me-2" aria-hidden="true">＋</span>Tambah Jadwal</a>
</div>
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Nama Jadwal</th><th>Tanggal</th><th>Lokasi</th><th>Kuota</th><th>Status</th><th>Tindakan</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $scheduleBadgeClass = 'text-bg-secondary';
                    $scheduleStatusText = 'Ditutup';

                    if ($schedule->status === 'open') {
                        $scheduleBadgeClass = 'text-bg-success';
                        $scheduleStatusText = 'Dibuka';
                    }
                ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($schedule->title); ?></td><td><?php echo e($schedule->schedule_date->format('d M Y')); ?><div class="small text-secondary"><?php echo e(substr($schedule->start_time,0,5)); ?>–<?php echo e(substr($schedule->end_time,0,5)); ?></div></td>
                    <td><?php echo e($schedule->location); ?></td><td><?php echo e($schedule->quota); ?></td>
<td>
                        <span class="badge <?php echo e($scheduleBadgeClass); ?>">
                            <?php echo e($scheduleStatusText); ?>

                        </span>
                    </td>
                    <td><div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.schedules.edit', $schedule)); ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                        <form method="POST" action="<?php echo e(route('admin.schedules.destroy', $schedule)); ?>" onsubmit="return confirm('Hapus jadwal ini? Pendaftaran terkait juga akan terhapus.');"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger">Hapus</button>
                        </form>
                    </div></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-secondary py-4">Belum ada jadwal. Klik Tambah Jadwal untuk membuat jadwal donor.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($schedules->hasPages()): ?><div class="card-footer bg-white"><?php echo e($schedules->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LSP_Donor_Darah\LSP_Donor_Darah\resources\views/admin/schedules/index.blade.php ENDPATH**/ ?>