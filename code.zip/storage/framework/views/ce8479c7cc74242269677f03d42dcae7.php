<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'DonorDarah'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-light">
<?php if(auth()->guest()): ?>
    <?php
        $isAuthPage = request()->routeIs('login', 'register');
        $guestMainClass = 'container py-4 py-lg-5';

        if ($isAuthPage) {
            $guestMainClass = 'auth-page';
        }
    ?>

    <?php if(!$isAuthPage): ?>
        <nav class="navbar navbar-expand-lg public-navbar bg-white border-bottom sticky-top">
            <div class="container">
                <a class="navbar-brand fw-bold text-danger d-flex align-items-center gap-2" href="<?php echo e(route('home')); ?>">
                    <span class="brand-drop">✚</span>
                    DonorDarah
                </a>

                <button
                    class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#publicNavbar"
                    aria-controls="publicNavbar"
                    aria-expanded="false"
                    aria-label="Buka navigasi"
                >
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="publicNavbar">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('home')]); ?>"
                                href="<?php echo e(route('home')); ?>"
                            >
                                Beranda
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>#informasi">
                                Informasi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a
                                class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-link', 'active' => request()->routeIs('services')]); ?>"
                                href="<?php echo e(route('services')); ?>"
                            >
                                Layanan
                            </a>
                        </li>
                    </ul>

                    <div class="d-flex gap-2 align-items-center">
                        <a class="btn btn-outline-danger px-4" href="<?php echo e(route('login')); ?>">
                            Masuk
                        </a>
                        <a class="btn btn-danger px-4" href="<?php echo e(route('register')); ?>">
                            Daftar
                        </a>
                    </div>
                </div>
            </div>
        </nav>
    <?php endif; ?>

    <main class="<?php echo e($guestMainClass); ?>">
<?php else: ?>
    <?php
        $isAdmin = auth()->user()->role === 'admin';
        $appHome = route('dashboard');
        $pageTitle = 'Dashboard';
        $userRoleLabel = 'Pendonor';

        if ($isAdmin) {
            $appHome = route('admin.dashboard');
            $pageTitle = 'Dashboard Admin';
            $userRoleLabel = 'Administrator';
        }

    ?>

    <div class="app-shell">
        <aside class="app-sidebar d-none d-lg-flex flex-column">
            <a class="sidebar-brand text-white text-decoration-none" href="<?php echo e($appHome); ?>">
                <span class="brand-drop brand-drop-light">✚</span>
                DonorDarah
            </a>

            <div class="sidebar-label">MENU UTAMA</div>

            <?php if($isAdmin): ?>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.dashboard')]); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                    <span>▦</span> Dashboard
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.accounts.*')]); ?>" href="<?php echo e(route('admin.accounts.index')); ?>">
                    <span>♙</span> Verifikasi Akun
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.schedules.*')]); ?>" href="<?php echo e(route('admin.schedules.index')); ?>">
                    <span>▣</span> Jadwal Donor
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.registrations.*')]); ?>" href="<?php echo e(route('admin.registrations.index')); ?>">
                    <span>☷</span> Pendaftaran
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.registrations.*')]); ?>" href="<?php echo e(route('admin.registrations.index')); ?>">
                    <span>▤</span> Pembayaran
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.announcements.*')]); ?>" href="<?php echo e(route('admin.announcements.index')); ?>">
                    <span>▧</span> Pengumuman
                </a>
            <?php else: ?>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('dashboard')]); ?>" href="<?php echo e(route('dashboard')); ?>">
                    <span>▦</span> Dashboard
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('services')]); ?>" href="<?php echo e(route('services')); ?>">
                    <span>▣</span> Layanan Donor
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('donor.registrations.*')]); ?>" href="<?php echo e(route('donor.registrations.index')); ?>">
                    <span>◷</span> Riwayat Donor
                </a>
                <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('profile.*')]); ?>" href="<?php echo e(route('profile.edit')); ?>">
                    <span>♙</span> Profil Saya
                </a>
            <?php endif; ?>

            <div class="sidebar-spacer"></div>

            <form action="<?php echo e(route('logout')); ?>" method="POST" class="sidebar-logout">
                <?php echo csrf_field(); ?>
                <button type="submit" class="sidebar-link w-100 text-start border-0">
                    <span class="logout-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 2v10" />
                            <path d="M5.6 5.6a8.5 8.5 0 1 0 12.8 0" />
                        </svg>
                    </span>
                    Keluar
                </button>
            </form>
        </aside>

        <div class="app-main">
            <header class="app-topbar bg-white border-bottom">
                <div class="d-flex align-items-center gap-3">
                    <button
                        class="btn btn-outline-danger d-lg-none"
                        type="button"
                        data-bs-toggle="offcanvas"
                        data-bs-target="#mobileSidebar"
                        aria-controls="mobileSidebar"
                        aria-label="Buka menu"
                    >
                        ☰
                    </button>

                    <div>
                        <h1 class="h4 fw-bold mb-0"><?php echo $__env->yieldContent('page-title', $pageTitle); ?></h1>
                        <div class="small text-secondary d-none d-sm-block">
                            Sistem Pendaftaran Donor Darah Online
                        </div>
                    </div>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <span class="avatar-circle">
                        <?php echo e(mb_substr(auth()->user()->name, 0, 1)); ?>

                    </span>
                    <div class="d-none d-sm-block">
                        <div class="small fw-semibold"><?php echo e(auth()->user()->name); ?></div>
                        <div class="small text-secondary"><?php echo e($userRoleLabel); ?></div>
                    </div>
                </div>
            </header>

            <div
                class="offcanvas offcanvas-start app-mobile-sidebar"
                tabindex="-1"
                id="mobileSidebar"
                aria-labelledby="mobileSidebarLabel"
            >
                <div class="offcanvas-header app-sidebar-mobile-head">
                    <h2 class="offcanvas-title h5 fw-bold text-white" id="mobileSidebarLabel">
                        <span class="brand-drop brand-drop-light">✚</span>
                        DonorDarah
                    </h2>
                    <button
                        type="button"
                        class="btn-close btn-close-white"
                        data-bs-dismiss="offcanvas"
                        aria-label="Tutup"
                    ></button>
                </div>

                <div class="offcanvas-body d-flex flex-column">
                    <?php if($isAdmin): ?>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.dashboard')]); ?>" href="<?php echo e(route('admin.dashboard')); ?>">▦ Dashboard</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.accounts.*')]); ?>" href="<?php echo e(route('admin.accounts.index')); ?>">♙ Verifikasi Akun</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.schedules.*')]); ?>" href="<?php echo e(route('admin.schedules.index')); ?>">▣ Jadwal Donor</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.registrations.*')]); ?>" href="<?php echo e(route('admin.registrations.index')); ?>">☷ Pendaftaran</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.registrations.*')]); ?>" href="<?php echo e(route('admin.registrations.index')); ?>">▤ Pembayaran</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('admin.announcements.*')]); ?>" href="<?php echo e(route('admin.announcements.index')); ?>">▧ Pengumuman</a>
                    <?php else: ?>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('dashboard')]); ?>" href="<?php echo e(route('dashboard')); ?>">▦ Dashboard</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('services')]); ?>" href="<?php echo e(route('services')); ?>">▣ Layanan Donor</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('donor.registrations.*')]); ?>" href="<?php echo e(route('donor.registrations.index')); ?>">◷ Riwayat Donor</a>
                        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['sidebar-link', 'active' => request()->routeIs('profile.*')]); ?>" href="<?php echo e(route('profile.edit')); ?>">♙ Profil Saya</a>
                    <?php endif; ?>

                    <div class="sidebar-spacer"></div>

                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="sidebar-link w-100 text-start border-0" type="submit">
                            <span class="logout-icon" aria-hidden="true">↪</span>
                            Keluar
                        </button>
                    </form>
                </div>
            </div>

            <main class="app-content">
<?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

<?php if(auth()->guest()): ?>
    </main>

    <?php if(!$isAuthPage): ?>
        <footer class="border-top bg-white mt-5">
            <div class="container py-4 d-flex flex-column flex-md-row justify-content-between gap-2">
                <span class="fw-semibold text-danger">🩸 DonorDarah</span>
                <span class="text-secondary small">Sistem Pendaftaran Donor Darah Online</span>
            </div>
        </footer>
    <?php endif; ?>
<?php else: ?>
            </main>
        </div>
    </div>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\LSP_Donor_Darah\LSP_Donor_Darah\resources\views/layouts/app.blade.php ENDPATH**/ ?>