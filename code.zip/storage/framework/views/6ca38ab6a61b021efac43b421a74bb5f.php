<?php $__env->startSection('title', 'Verifikasi Akun | DonorDarah'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div><h1 class="h2 fw-bold">Verifikasi Akun Pendonor</h1><p class="text-secondary mb-0">Setujui atau tolak akun yang telah mendaftar.</p></div>
</div>
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Nama</th><th>NIK</th><th>Telepon</th><th>Email</th><th>Status</th><th>Tindakan</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $accountBadgeClass = 'text-bg-warning';
                    $accountStatusText = 'Menunggu';

                    if ($user->account_status === 'approved') {
                        $accountBadgeClass = 'text-bg-success';
                        $accountStatusText = 'Disetujui';
                    } elseif ($user->account_status === 'rejected') {
                        $accountBadgeClass = 'text-bg-danger';
                        $accountStatusText = 'Ditolak';
                    }
                ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($user->name); ?></td><td><?php echo e($user->nik ?? '-'); ?></td><td><?php echo e($user->nomor_telepon ?? '-'); ?></td><td><?php echo e($user->email); ?></td>
<td>
                        <span class="badge <?php echo e($accountBadgeClass); ?>">
                            <?php echo e($accountStatusText); ?>

                        </span>
                    </td>
                    <td>
                        <div class="d-flex gap-2">
                            <form method="POST" action="<?php echo e(route('admin.accounts.status', $user)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="account_status" value="approved"><button class="btn btn-sm btn-success" type="submit">Setujui</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.accounts.status', $user)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="account_status" value="rejected"><button class="btn btn-sm btn-outline-danger" type="submit">Tolak</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-secondary py-4">Belum ada akun pendonor.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($users->hasPages()): ?><div class="card-footer bg-white"><?php echo e($users->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LSP_Donor_Darah\LSP_Donor_Darah\resources\views/admin/accounts/index.blade.php ENDPATH**/ ?>