<?php $__env->startSection('title', 'Verifikasi Pendaftaran | DonorDarah'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div><h1 class="h2 fw-bold">Verifikasi Pendaftaran Donor</h1><p class="text-secondary mb-0">Tinjau pendaftaran pendonor untuk setiap jadwal.</p></div>
</div>
<div class="card border-0 shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Pendonor</th><th>Jadwal</th><th>Tanggal</th><th>Status</th><th>Tindakan</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $registrationBadgeClass = 'text-bg-warning';
                    $registrationStatusText = 'Menunggu';

                    if ($registration->registration_status === 'approved') {
                        $registrationBadgeClass = 'text-bg-success';
                        $registrationStatusText = 'Disetujui';
                    } elseif ($registration->registration_status === 'rejected') {
                        $registrationBadgeClass = 'text-bg-danger';
                        $registrationStatusText = 'Ditolak';
                    }
                ?>
                <tr>
                    <td><?php echo e($registration->user?->name); ?><div class="small text-secondary"><?php echo e($registration->user?->email); ?></div><div class="small text-secondary">Telp: <?php echo e($registration->user?->nomor_telepon ?? '-'); ?> · NIK: <?php echo e($registration->user?->nik ?? '-'); ?></div><div class="small text-secondary">Golongan: <?php echo e($registration->user?->golongan_darah ?? '-'); ?> · Usia: <?php echo e($registration->user?->tanggal_lahir?->age ?? '-'); ?> tahun</div></td>
                    <td><?php echo e($registration->schedule?->title); ?></td><td><?php echo e($registration->schedule?->schedule_date?->format('d M Y')); ?></td>
<td>
                        <span class="badge <?php echo e($registrationBadgeClass); ?>">
                            <?php echo e($registrationStatusText); ?>

                        </span>
                    </td>
                    <td><div class="d-flex gap-2">
                        <form method="POST" action="<?php echo e(route('admin.registrations.status', $registration)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="registration_status" value="approved"><button class="btn btn-sm btn-success">Setujui</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.registrations.status', $registration)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="registration_status" value="rejected"><button class="btn btn-sm btn-outline-danger">Tolak</button>
                        </form>
                    </div></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-secondary py-4">Belum ada pendaftaran donor.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($registrations->hasPages()): ?><div class="card-footer bg-white"><?php echo e($registrations->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LSP_Donor_Darah\LSP_Donor_Darah\resources\views/admin/registrations/index.blade.php ENDPATH**/ ?>