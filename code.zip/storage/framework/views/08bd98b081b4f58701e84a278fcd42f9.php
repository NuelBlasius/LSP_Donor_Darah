<?php $__env->startSection('title', 'Dashboard Admin | DonorDarah'); ?>
<?php $__env->startSection('page-title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-wrap">
    <div class="mb-4">
        <span class="badge text-bg-danger rounded-pill mb-2">PANEL PENGELOLA</span>
        <h2 class="h3 fw-bold mb-1">Selamat datang, <?php echo e(auth()->user()->name); ?></h2>
        <p class="text-secondary mb-0">Pantau proses verifikasi dan kelola kegiatan donor darah dari satu tempat.</p>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-sm-6 col-xl-3">
            <a href="<?php echo e(route('admin.accounts.index')); ?>" class="admin-stat-card text-decoration-none h-100">
                <div class="stat-icon stat-icon-red">♙</div><div class="small text-secondary">Akun Menunggu Verifikasi</div><div class="h2 fw-bold text-dark my-2"><?php echo e($stats['pending_accounts']); ?></div><span class="link-danger small fw-semibold">Periksa akun →</span>
            </a>
        </div>
        <div class="col-sm-6 col-xl-3">
            <a href="<?php echo e(route('admin.registrations.index')); ?>" class="admin-stat-card text-decoration-none h-100">
                <div class="stat-icon stat-icon-yellow">▣</div><div class="small text-secondary">Pendaftaran Menunggu</div><div class="h2 fw-bold text-dark my-2"><?php echo e($stats['pending_registrations']); ?></div><span class="link-danger small fw-semibold">Verifikasi →</span>
            </a>
        </div>
        <div class="col-sm-6 col-xl-3">
            <a href="<?php echo e(route('admin.registrations.index')); ?>" class="admin-stat-card text-decoration-none h-100">
                <div class="stat-icon stat-icon-green">▤</div><div class="small text-secondary">Pembayaran Menunggu</div><div class="h2 fw-bold text-dark my-2"><?php echo e($stats['pending_payments']); ?></div><span class="link-danger small fw-semibold">Periksa bukti →</span>
            </a>
        </div>
        <div class="col-sm-6 col-xl-3">
            <a href="<?php echo e(route('admin.schedules.index')); ?>" class="admin-stat-card text-decoration-none h-100">
                <div class="stat-icon stat-icon-red">▦</div><div class="small text-secondary">Jadwal Donor Aktif</div><div class="h2 fw-bold text-dark my-2"><?php echo e($stats['open_schedules']); ?></div><span class="link-danger small fw-semibold">Kelola jadwal →</span>
            </a>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\LSP_Donor_Darah\LSP_Donor_Darah\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>