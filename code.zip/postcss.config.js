export default {
    plugins: {
        autoprefixer: {},
    },
};
