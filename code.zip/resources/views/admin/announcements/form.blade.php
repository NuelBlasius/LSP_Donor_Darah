@extends('layouts.app')

@section('title', $announcement->exists ? 'Edit Pengumuman' : 'Buat Pengumuman')

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3"><h1 class="h4 fw-bold mb-0">{{ $announcement->exists ? 'Edit Pengumuman' : 'Buat Pengumuman' }}</h1></div>
            <div class="card-body p-4">
                @if ($errors->any())<div class="alert alert-danger"><ul class="mb-0">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
                <form method="POST" action="{{ $announcement->exists ? route('admin.announcements.update', $announcement) : route('admin.announcements.store') }}">
                    @csrf
                    @if ($announcement->exists) @method('PUT') @endif
                    <div class="mb-3"><label for="title" class="form-label">Judul</label><input id="title" name="title" class="form-control" value="{{ old('title', $announcement->title) }}" required></div>
                    <div class="mb-3"><label for="content" class="form-label">Isi Pengumuman</label><textarea id="content" name="content" rows="6" class="form-control" required>{{ old('content', $announcement->content) }}</textarea></div>
                    <div class="d-flex flex-wrap gap-3 mt-4"><button class="btn btn-danger px-4">{{ $announcement->exists ? 'Simpan Perubahan' : 'Publikasikan' }}</button>
                    <a href="{{ route('admin.announcements.index') }}" class="btn btn-outline-secondary px-4">Batal</a></div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
