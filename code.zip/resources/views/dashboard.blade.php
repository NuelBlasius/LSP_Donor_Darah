@extends('layouts.app')

@section('title', 'Dashboard Pendonor | DonorDarah')
@section('page-title', 'Dashboard')

@section('content')
<div class="dashboard-wrap">
    <section class="dashboard-welcome rounded-4 mb-4">
        <div class="row align-items-center g-3">
            <div class="col-lg-8">
                <div class="small text-danger fw-semibold mb-2">DASHBOARD PENDONOR</div>
                <h2 class="h3 fw-bold mb-2">Halo, {{ $user->name }}! <span aria-hidden="true">👋</span></h2>
                <p class="text-secondary mb-3">Terima kasih telah menjadi bagian dari pendonor darah. Pantau status akun dan pendaftaran Anda di sini.</p>
                <a href="{{ route('services') }}" class="btn btn-danger">Cari Jadwal Donor <span aria-hidden="true">→</span></a>
            </div>
            <div class="col-lg-4 text-center d-none d-lg-block"><img src="{{ asset('images/donor-illustration.svg') }}" class="welcome-art" alt=""></div>
        </div>
    </section>

    <section class="card border-0 shadow-sm mb-4">
        <div class="card-body p-3 p-lg-4 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <h2 class="h5 fw-bold mb-1">Status Verifikasi Akun</h2>
                @if ($user->account_status === 'approved')
                    <p class="text-secondary mb-0">Akun Anda telah disetujui. Anda dapat mendaftar jadwal donor yang tersedia.</p>
                @elseif ($user->account_status === 'rejected')
                    <p class="text-secondary mb-0">Akun belum disetujui. Silakan hubungi admin untuk informasi lebih lanjut.</p>
                @else
                    <p class="text-secondary mb-0">Admin sedang memeriksa akun Anda. Pendaftaran jadwal tersedia setelah akun disetujui.</p>
                @endif
            </div>
            <span class="badge fs-6 px-3 py-2 {{ $user->account_status === 'approved' ? 'text-bg-success' : ($user->account_status === 'rejected' ? 'text-bg-danger' : 'text-bg-warning') }}">
                {{ $user->account_status === 'approved' ? 'Terverifikasi' : ($user->account_status === 'rejected' ? 'Ditolak' : 'Menunggu Verifikasi') }}
            </span>
        </div>
    </section>

    <div class="row g-3 mb-4">
        <div class="col-md-4"><div class="stat-card h-100"><div class="stat-icon stat-icon-red">▦</div><div><div class="h3 fw-bold mb-0">{{ $totalRegistrations }}</div><div class="small text-secondary">Total Pendaftaran</div></div></div></div>
        <div class="col-md-4"><div class="stat-card h-100"><div class="stat-icon stat-icon-yellow">◷</div><div><div class="h3 fw-bold mb-0">{{ $pendingRegistrations }}</div><div class="small text-secondary">Menunggu Verifikasi</div></div></div></div>
        <div class="col-md-4"><div class="stat-card h-100"><div class="stat-icon stat-icon-green">✓</div><div><div class="h3 fw-bold mb-0">{{ $pendingPayments }}</div><div class="small text-secondary">Pembayaran Menunggu</div></div></div></div>
    </div>

    <section class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h2 class="h5 fw-bold mb-0">Pendaftaran Terbaru</h2>
            <a href="{{ route('donor.registrations.index') }}" class="link-danger fw-semibold small">Lihat Riwayat →</a>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light"><tr><th>Jadwal Donor</th><th>Tanggal</th><th>Status Pendaftaran</th><th>Status Pembayaran</th></tr></thead>
                <tbody>
                @forelse ($registrations as $registration)
                    <tr>
                        <td class="fw-semibold">{{ $registration->schedule?->title ?? 'Jadwal dihapus' }}</td>
                        <td>{{ $registration->schedule?->schedule_date?->format('d M Y') ?? '-' }}</td>
                        <td><span class="badge {{ $registration->registration_status === 'approved' ? 'text-bg-success' : ($registration->registration_status === 'rejected' ? 'text-bg-danger' : 'text-bg-warning') }}">{{ $registration->registration_status === 'approved' ? 'Disetujui' : ($registration->registration_status === 'rejected' ? 'Ditolak' : 'Menunggu') }}</span></td>
                        <td><span class="badge {{ $registration->payment_status === 'approved' ? 'text-bg-success' : ($registration->payment_status === 'rejected' ? 'text-bg-danger' : 'text-bg-secondary') }}">{{ $registration->payment_status === 'approved' ? 'Disetujui' : ($registration->payment_status === 'rejected' ? 'Ditolak' : 'Menunggu') }}</span></td>
                    </tr>
                @empty
                    <tr><td colspan="4" class="text-center text-secondary py-4">Belum ada pendaftaran. Gunakan menu Layanan Donor untuk melihat jadwal yang tersedia.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </section>
</div>


    <section class="card border-0 shadow-sm mt-4">
        <div class="card-header bg-white py-3">
            <h2 class="h5 fw-bold mb-0">Pengumuman</h2>
            <p class="small text-secondary mb-0">Informasi terbaru dari pengelola donor.</p>
        </div>
        <div class="card-body">
            <div class="row g-3">
                @forelse ($announcements as $announcement)
                    <div class="col-md-6">
                        <article class="announcement-card h-100">
                            <div class="small text-danger fw-semibold">{{ $announcement->created_at->format('d M Y') }}</div>
                            <h3 class="h6 fw-bold mt-2">{{ $announcement->title }}</h3>
                            <p class="text-secondary mb-0">{{ $announcement->content }}</p>
                        </article>
                    </div>
                @empty
                    <div class="col-12"><p class="text-secondary mb-0">Belum ada pengumuman.</p></div>
                @endforelse
            </div>
        </div>
    </section>
@endsection
