# DonorDarah — Sistem Pendaftaran Donor Darah Online

Project Laravel untuk Case 16: Pendaftaran Donor Darah.

## Teknologi
- Laravel / PHP
- MySQL
- Bootstrap 5 (CSS dan komponen UI)
- Vite untuk bundling CSS/JavaScript

Tidak menggunakan Tailwind untuk tampilan aplikasi. Seluruh halaman utama, autentikasi, dashboard pendonor, dan panel admin menggunakan class Bootstrap.

## Fitur yang tersedia

### Pendonor
- Registrasi akun dengan nama, nomor telepon, NIK, jenis kelamin, golongan darah, tanggal lahir, alamat, email, dan password.
- Login dan logout.
- Melihat status verifikasi akun.
- Melihat layanan, jadwal donor, dan kuota; pengumuman terbaru tampil di dashboard.
- Mengonfirmasi data diri yang otomatis diambil dari profil saat mendaftar jadwal donor setelah akun disetujui.
- Melihat status pendaftaran.
- Mengunggah bukti pembayaran setelah pendaftaran disetujui.

### Admin
- Login admin.
- Melihat ringkasan proses di dashboard.
- Menyetujui atau menolak akun pendonor.
- CRUD jadwal donor (tambah, lihat, ubah, hapus).
- Menyetujui atau menolak pendaftaran donor.
- Memeriksa dan menyetujui atau menolak bukti pembayaran.
- CRUD pengumuman yang ditampilkan pada dashboard pendonor.

Catatan: konfirmasi pembayaran pada versi ini berupa unggah bukti pembayaran dan verifikasi admin, bukan payment gateway online.

## Instalasi
1. Buat database MySQL dan sesuaikan `.env`.
2. Jalankan:

```bash
composer install
npm install
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
npm run build
php artisan serve
```

Jika `APP_KEY` sudah ada di `.env`, tidak perlu menjalankan `php artisan key:generate` lagi.

Jalankan `npm run dev` pada terminal terpisah selama pengembangan.

**Jangan menjalankan `php artisan migrate:fresh` jika database berisi data penting**, karena perintah tersebut menghapus tabel dan data.

## Akun demo
Setelah `php artisan migrate --seed`:

- Admin: `admin@donor.test` / `admin12345`
- Pendonor disetujui: `andi@donor.test` / `donor12345`
- Pendonor menunggu verifikasi: `siti@donor.test` / `donor12345`

Akun dan password tersebut hanya untuk demonstrasi lokal. Ganti sebelum aplikasi dipublikasikan.

## Antarmuka dan navigasi
- Halaman publik (Beranda, Informasi, Layanan) ditampilkan sebelum login.
- Setelah login, pendonor masuk ke dashboard dengan menu Dashboard, Layanan Donor, dan Riwayat Donor.
- Admin mendapatkan menu khusus pengelolaan: Dashboard, Verifikasi Akun, Jadwal Donor, Pendaftaran, Pembayaran, dan Pengumuman.
- Menu Beranda tidak ditampilkan pada area login. Jika pengguna yang sudah login membuka `/`, aplikasi mengarahkannya kembali ke dashboard sesuai role.
- Tampilan menggunakan Bootstrap 5; tidak menggunakan Tailwind.
## Data profil pendonor dan pendaftaran jadwal
- Registrasi akun menyimpan nama, nomor telepon, NIK 16 digit, jenis kelamin, golongan darah, tanggal lahir, alamat, email, dan kata sandi.
- Data identitas disimpan pada tabel `users`; form pendaftaran jadwal menampilkan data tersebut secara otomatis.
- Usia pada form donor dihitung dari `tanggal_lahir`, bukan dimasukkan manual.
- Pendonor dapat memperbarui data melalui menu **Profil Saya**.
- Pengumuman terbaru ditampilkan pada dashboard pendonor.
- Untuk database yang sudah ada, jalankan `php artisan migrate` agar kolom profil baru ditambahkan. Jangan gunakan `migrate:fresh` jika ingin mempertahankan data.
